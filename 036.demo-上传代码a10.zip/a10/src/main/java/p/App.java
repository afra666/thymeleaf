package p;

        import org.springframework.stereotype.Controller;
        import org.springframework.web.bind.annotation.RequestMapping;
        import org.springframework.web.bind.annotation.RequestMethod;
        import org.springframework.web.bind.annotation.ResponseBody;

        import javax.servlet.http.HttpServletRequest;
        import java.io.BufferedWriter;
        import java.io.File;
        import java.io.FileWriter;
        import java.io.IOException;

@Controller
public class App {
    @RequestMapping(value = "")
    public String indexFunc() {
        return "a";
    }

    @ResponseBody
    @RequestMapping(value = "/doForm",method = RequestMethod.POST)
    public String toString(HttpServletRequest request) throws IOException {
        String username=request.getParameter("username");
        String code01=request.getParameter("code01");
        NowDate nowDate=new NowDate();
        String  todayDirName=nowDate.yyyyMMdd();


        //windows
        //File file=new File("D:/webtest/"+todayDirName+"/"+username+"-code01"+".c");
        //File dir=new File("D:/webtest/"+todayDirName);
        //ubuntu
        File file=new File("/home/ad/webtest/"+todayDirName+"/"+username+"-code01"+".c");
        File dir=new File("/home/ad/webtest/"+todayDirName);

        if (!dir.exists()){
            dir.mkdirs();
            System.out.println("目录创建成功");
        }
        if (!file.exists()){
            file.createNewFile();
            BufferedWriter out = new BufferedWriter(new FileWriter(file));
            out.write(code01); // \r\n即为换行
            out.flush(); // 把缓存区内容压入文件
            out.close(); // 最后记得关闭文件
            System.out.println("代码提交成功");
        }
        return "代码已提交";
    }
}
