package p;

import java.text.SimpleDateFormat;
import java.util.Date;

public class NowDate {
    public String yyyyMMdd(){
        Date date=new Date();
        SimpleDateFormat simFormat=new SimpleDateFormat("yyyy-MM-dd");
        return simFormat.format(date);
    }
}
