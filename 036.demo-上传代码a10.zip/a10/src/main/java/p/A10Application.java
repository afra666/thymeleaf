package p;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A10Application {

    public static void main(String[] args) {
        SpringApplication.run(A10Application.class, args);

    }

}
