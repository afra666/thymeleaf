package p;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A10ApplicationTests {

    @Test
    void contextLoads() {
    }

}
