package p;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

@Controller
public class UploadController {
    @RequestMapping("")
    public String index(){
        return "index";
    }
    /***
     *
     * @param file
     * @param request
     * @return
     */
    @RequestMapping(value="/upload",method = RequestMethod.POST)
    @ResponseBody
    public String uploadFile(MultipartFile file, HttpServletRequest request) {
        try {
            String dir;

            //Ubuntu
            //dir="/home/ad/webFiles";

            //windows
            dir="D:/webFiles";

            //tomcat缓存路径
            //dir=request.getServletContext().getRealPath("/upload");

            System.out.println(dir);

            File fileDir=new File(dir);
            if (!fileDir.exists()){
                fileDir.mkdirs();
            }
            String fileSuffix=file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
            String fileName= UUID.randomUUID().toString()+fileSuffix;
            File files=new File(fileDir+"/"+fileName);


            file.transferTo(files);
        } catch (IOException e) {
            e.printStackTrace();
            return "上传失败";
        }
        return "已上传";
    }
}
